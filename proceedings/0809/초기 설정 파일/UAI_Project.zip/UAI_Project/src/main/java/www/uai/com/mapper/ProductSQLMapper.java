package www.uai.com.mapper;

public interface ProductSQLMapper {

}
