package www.uai.com.service.impl;

import www.uai.com.service.ProductService;

public class ProductServiceImpl implements ProductService{

}
