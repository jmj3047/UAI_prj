package www.uai.com.service;

public interface ContentService {

}
