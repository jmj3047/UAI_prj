package com.ja.springex.vo;

import java.util.ArrayList;

public class PageVO {
	
	private int nowPage;
	private int startPage;
	private int maxPage;
	private int endPage;
	private int limit;
	
	public PageVO(int nowPage, int startPage, int maxPage, int endPage, int limit) {
		super();
		this.nowPage = nowPage;
		this.startPage = startPage;
		this.maxPage = maxPage;
		this.endPage = endPage;
		this.limit = limit;
	}

	public int getNowPage() {
		return nowPage;
	}

	public void setNowPage(int nowPage) {
		this.nowPage = nowPage;
	}

	public int getStartPage() {
		return startPage;
	}

	public void setStartPage(int startPage) {
		this.startPage = startPage;
	}

	public int getMaxPage() {
		return maxPage;
	}

	public void setMaxPage(int maxPage) {
		this.maxPage = maxPage;
	}

	public int getEndPage() {
		return endPage;
	}

	public void setEndPage(int endPage) {
		this.endPage = endPage;
	}

	public int getLimit() {
		return limit;
	}

	public void setLimit(int limit) {
		this.limit = limit;
	}

}
