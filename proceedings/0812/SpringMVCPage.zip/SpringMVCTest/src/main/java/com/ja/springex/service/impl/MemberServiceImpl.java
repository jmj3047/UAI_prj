package com.ja.springex.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ja.springex.mapper.MembersSQLMapper;
import com.ja.springex.service.memberService;
import com.ja.springex.vo.MemberVO;
import com.ja.springex.vo.SessionDataVO;

@Service
public class MemberServiceImpl implements memberService{ //memberService 인터페이스 상속받음 ---> 여기서 사용해야지

	@Autowired //자동으로 값 가져와서 받기, dao 과정에서 실질적으로 dao를 실행하는 장소
	private MembersSQLMapper membersSQLMapper; // new dao
	
	public void joinMember(MemberVO vo) {
		
		membersSQLMapper.insert(vo); //실제적인 dao 실행
		
	}

	@Override
	public SessionDataVO loginProcess(MemberVO vo) {
		// TODO Auto-generated method stub
		
		// dao 연동 수행
		MemberVO result = membersSQLMapper.selectById(vo.getM_id());
		
		SessionDataVO sessionData = null;
		
		// result로 받아온 값으로 로그인 수행 
		if(result != null && result.getM_pw().equals(vo.getM_pw())) {
			sessionData = new SessionDataVO(result.getM_idx(), result.getM_nick());
		}else {
			
		}
			
		return sessionData;
	}

	@Override
	public void deleteMember(MemberVO vo) {
		// TODO Auto-generated method stub
		
		MemberVO result = membersSQLMapper.selectById(vo.getM_id());
		
		if(result != null && result.getM_pw().equals(vo.getM_pw())) {
			membersSQLMapper.deleteByIdx(result);
		}else {
		
		}
	}

	@Override
	public boolean isExistID(MemberVO requestParam) {
		// TODO Auto-generated method stub
		MemberVO data = membersSQLMapper.selectById(requestParam.getM_id());
		
		//중복 아이디가 있으면 
		if(data != null) {
			return true;
		}
		
		return false;
	}
	
}
