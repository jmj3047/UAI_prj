package com.ja.springex.service;

import java.util.ArrayList;

import com.ja.springex.vo.BoardDataPageVO;
import com.ja.springex.vo.BoardDataVO;
import com.ja.springex.vo.ContentVO;
import com.ja.springex.vo.PageVO;
import com.ja.springex.vo.UploadFileVO;

//impl 에서 사용할 메서드들 총 정리
public interface ContentService {

	public BoardDataPageVO getContentsList(String searchWord, String searchTarget, PageVO pageVO); 
	
	public BoardDataVO readContent(ContentVO requestParam); //이거 그냥 string으로 받아도 됨( ?c_idx 방식으로 ) //vo 말고 이름을 좀 지어주면 편함(param: 넘겨받은 애)
	
	public void deleteContent(ContentVO requestParam);
	
	public void updateContent(ContentVO requestParam);
	
	public void writeContent(ContentVO requestParam, ArrayList<UploadFileVO> fileList);
	
	public void increaseCount(ContentVO requestParam);
	
}
