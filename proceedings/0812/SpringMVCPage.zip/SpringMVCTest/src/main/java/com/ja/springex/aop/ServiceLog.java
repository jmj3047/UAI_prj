package com.ja.springex.aop;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;
import org.springframework.stereotype.Service;

//service 시작.끝 찍기 ---> 어디서 오류가 났냐?????
@Service
@Aspect
public class ServiceLog {

	@Pointcut("execution(* com.ja.springex.service..*Impl.*(..))")
	public void servicePointCut() {}
	
	@Around("servicePointCut()")
	public Object printLog(ProceedingJoinPoint pjp) {
		Object obj = null;
		
		System.out.println("======= " + pjp.getSignature().getName() + " 시작 =======");
		
		try {
			obj = pjp.proceed();
		}catch(Throwable e) {
			e.printStackTrace();
		}
		
		System.out.println("======= " + pjp.getSignature().getName() + " 끝 =======");
		
		return obj;
	}
}
