package com.ja.springex.mapper;

import java.util.ArrayList;

import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;

import com.ja.springex.vo.ContentVO;
import com.ja.springex.vo.PageVO;

public interface ContentsSQLMapper { 

	@Select("SELECT BOARD_CONTENTS_SEQ.NEXTVAL FROM DUAL")
	public String getKey(); // seq 자체를 직접 먼저 가져와서 우리가 변환시켜 준 후 insert 과정에서 직접 넣어주기 (키 가져오기)
	
	@Select("SELECT bd2.* FROM (SELECT bd.*, ROWNUM AS rnum FROM (SELECT * FROM BOARD_CONTENTS ORDER BY C_IDX DESC) bd) bd2 WHERE rnum BETWEEN #{nowPage*limit-limit+1} AND #{nowPage*limit};")
	public ArrayList<ContentVO> selectByPageNum(PageVO vo);
	
	@Select("SELECT * FROM BOARD_CONTENTS WHERE C_IDX = #{c_idx}") 
	public ContentVO selectByIdx(String c_idx);
	
	@Update("UPDATE BOARD_CONTENTS SET C_TITLE = #{c_title}, C_CONTENTS = #{c_contents} WHERE C_IDX = #{c_idx}")
	public void updateByIdx(ContentVO vo);
	
	@Insert("INSERT INTO BOARD_CONTENTS VALUES(#{c_idx},#{m_idx},#{c_title},#{c_contents},0,SYSDATE)")
	public void insert(ContentVO vo);
	
	@Delete("DELETE FROM BOARD_CONTENTS WHERE C_IDX = #{c_idx}")
	public void deleteByIdx(String c_idx);
	
	//@Select("SELECT * FROM BOARD CONTENTS WHERE C_TITLE LIKE '%${searchWord}%' ORDER BY C_IDX DESC") //searchWord를 따옴표 뗀 문자열로 만들고 싶을 때는 일단 ${] 붙이기
	@Select("SELECT * FROM BOARD_CONTENTS WHERE ${searchTarget} LIKE '%'||#{searchWord}||'%' ORDER BY C_IDX DESC")
	public ArrayList<ContentVO> selectBySearchWord(
			@Param("searchWord") String searchWord, 
			@Param("searchTarget") String searchTarget); // 이런식으로 param 붙이면 두개 이상의 값도 받을 수 있음(그냥 VO 하나 새로 파자....)
	
	// 스트링과 VO를 동시에 받아오고 싶은 경우에도 param 처리할 수 있음. #{VO.vo안의 객체} 이런식으로
	
	@Update("UPDATE BOARD_CONTENTS SET C_COUNT = #{c_count} + 1 WHERE C_IDX = #{c_idx}")
	public void increaseCount(ContentVO vo);

	@Select("SELECT COUNT(*) FROM BOARD_CONTENTS")
	public int getListCount();
	
}
