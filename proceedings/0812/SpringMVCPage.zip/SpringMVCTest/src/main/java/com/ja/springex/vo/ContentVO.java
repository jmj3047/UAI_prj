package com.ja.springex.vo;

public class ContentVO {

	private String c_idx;
	private String m_idx;
	private String c_title;
	private String c_contents;
	private String c_count;
	private String c_writedate;
	
	public ContentVO() {
		
	}

	public ContentVO(String c_idx, String m_idx, String c_title, String c_contents, String c_count,
			String c_writedate) {
		super();
		this.c_idx = c_idx;
		this.m_idx = m_idx;
		this.c_title = c_title;
		this.c_contents = c_contents;
		this.c_count = c_count;
		this.c_writedate = c_writedate;
	}

	public String getC_idx() {
		return c_idx;
	}

	public void setC_idx(String c_idx) {
		this.c_idx = c_idx;
	}

	public String getM_idx() {
		return m_idx;
	}

	public void setM_idx(String m_idx) {
		this.m_idx = m_idx;
	}

	public String getC_title() {
		return c_title;
	}

	public void setC_title(String c_title) {
		this.c_title = c_title;
	}

	public String getC_contents() {
		return c_contents;
	}

	public void setC_contents(String c_contents) {
		this.c_contents = c_contents;
	}

	public String getC_count() {
		return c_count;
	}

	public void setC_count(String c_count) {
		this.c_count = c_count;
	}

	public String getC_writedate() {
		return c_writedate;
	}

	public void setC_writedate(String c_writedate) {
		this.c_writedate = c_writedate;
	}
	
}
