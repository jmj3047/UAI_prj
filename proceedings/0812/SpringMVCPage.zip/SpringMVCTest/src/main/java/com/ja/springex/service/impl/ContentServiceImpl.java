package com.ja.springex.service.impl;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.ja.springex.mapper.ContentsSQLMapper;
import com.ja.springex.mapper.MembersSQLMapper;
import com.ja.springex.mapper.UploadFileSQLMapper;
import com.ja.springex.service.ContentService;
import com.ja.springex.vo.BoardDataPageVO;
import com.ja.springex.vo.BoardDataVO;
import com.ja.springex.vo.ContentVO;
import com.ja.springex.vo.MemberVO;
import com.ja.springex.vo.PageVO;
import com.ja.springex.vo.UploadFileVO;

@Service
public class ContentServiceImpl implements ContentService{

	//dao 사용할 수 있게
	@Autowired
	private ContentsSQLMapper contentsSQLMapper;
	@Autowired
	private MembersSQLMapper membersSQLMapper;
	@Autowired
	private UploadFileSQLMapper uploadFileSQLMapper;
	
	@Override
	public BoardDataPageVO getContentsList(String searchWord, String searchTarget, PageVO pageParam) {
		// TODO Auto-generated method stub
		
		BoardDataPageVO boardDataList = new BoardDataPageVO();
		
		ArrayList<BoardDataVO> dataList = new ArrayList<BoardDataVO>();
		
		ArrayList<ContentVO> contentList = null;
		
		// 페이징 처리 구현

		// 한 페이지에 보여줄 게시글 개수 설정
		int limit = 10;
		pageParam.setLimit(limit);
		
		// 한 페이지에 보여줄 페이지의 개수 설정
		int pageLimit = 5;
		                                                                                             
		// 게시글 총 개수 가져오기
		int listCount = contentsSQLMapper.getListCount();                                                                 
		                                                                                                   
		System.out.println("리스트 총 개수 : " + listCount);

		// 끝페이지 설정
		int maxPage = (int)(Math.ceil((double) listCount / pageParam.getLimit()));                                      
		pageParam.setMaxPage(maxPage);
		
		// 각 페이지 별 첫페이지&끝페이지 설정
		int startPage = (int)(Math.ceil((double) pageParam.getNowPage()/pageLimit));
		pageParam.setStartPage(startPage);
		int endPage = startPage + (pageLimit -1);                                                                       
		if(endPage > maxPage) {                                                                            
		    pageParam.setEndPage(maxPage);                                           
		}else {
			pageParam.setEndPage(endPage);
		}
		///////////////
		
		if(searchWord == null) {
			contentList = contentsSQLMapper.selectByPageNum(pageParam);
			
		}else {
		
			contentList = contentsSQLMapper.selectBySearchWord(searchWord,searchTarget);
			
		}
			
		for(ContentVO content : contentList) {
		
			MemberVO member = membersSQLMapper.selectByIdx(content.getM_idx()); 
				
			BoardDataVO data = new BoardDataVO(member,content,null);
				
			dataList.add(data);
		}

		boardDataList.setPagevo(pageParam);
		boardDataList.setBoardDataList(dataList);
		
		return boardDataList;
	}

	@Override
	public BoardDataVO readContent(ContentVO requestParam) {
		// TODO Auto-generated method stub
		String c_idx = requestParam.getC_idx();
		
		ContentVO content = contentsSQLMapper.selectByIdx(c_idx);
		
		System.out.println(content.getC_writedate());
		
		MemberVO member = membersSQLMapper.selectByIdx(content.getM_idx());
		
		ArrayList<UploadFileVO> fileList = new ArrayList<UploadFileVO>();
		fileList = uploadFileSQLMapper.selectByC_idx(c_idx);
		
		//for loop는...? jsp에서 돌리기
		
		return new BoardDataVO(member,content,fileList);
		
	}

	@Override
	public void deleteContent(ContentVO requestParam) {
		// TODO Auto-generated method stub
		
		String c_idx = requestParam.getC_idx();
		
		contentsSQLMapper.deleteByIdx(c_idx);
		
	}

	@Override
	public void updateContent(ContentVO requestParam) {
		// TODO Auto-generated method stub

		contentsSQLMapper.updateByIdx(requestParam);
	
	}

	@Override
	@Transactional //도중에 한 과정에서 오류가 발생하면 rollback 시킨다(atomicity)
	public void writeContent(ContentVO requestParam, ArrayList<UploadFileVO> fileList) {
		// TODO Auto-generated method stub
		
		// 키 가져오기(c_idx)
		String key = contentsSQLMapper.getKey();
		
		// 키 넣어주기(c_idx)
		requestParam.setC_idx(key);
		
		//db에 넣기
		contentsSQLMapper.insert(requestParam);
		
		// 파일 업로드 시키기(파일은 여러 개일 수 있음)
		for(UploadFileVO vo : fileList) {
			
			vo.setC_idx(key);
			
			uploadFileSQLMapper.insert(vo);
			
		}

		
	}

	@Override
	public void increaseCount(ContentVO requestParam) {
		// TODO Auto-generated method stub
		
		String c_idx = requestParam.getC_idx();
		
		ContentVO requestParam1 = contentsSQLMapper.selectByIdx(c_idx);
		
		contentsSQLMapper.increaseCount(requestParam1);
	}

	public ArrayList<BoardDataVO> getContentsList(String searchWord, String searchTarget) {
		// TODO Auto-generated method stub
		return null;
	}
	
}
