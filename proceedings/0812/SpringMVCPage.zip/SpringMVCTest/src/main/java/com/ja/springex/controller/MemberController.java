package com.ja.springex.controller;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.ja.springex.service.memberService;
import com.ja.springex.service.impl.MemberServiceImpl;
import com.ja.springex.vo.MemberVO;
import com.ja.springex.vo.SessionDataVO;

@Controller // 보통 request, response, session 객체는 여기 controller에서 처리
public class MemberController {
	
	@Autowired //인터페이스를 자동 주입시키기
	memberService memberService;
	
	@RequestMapping("/loginForm") // 어떤 양식이 나와야하는 경우 form, 프로세스를 돌려야 하는 경우 action
	public String loginForm() {
		return "loginForm";
	}
	
	@RequestMapping("/joinMemberForm")
	public String joinMemberForm() {
		return "joinMemberForm";
	}
	
	@RequestMapping("/joinMemberAction")
	public String joinMemberAction(MemberVO vo) {
		
		// DAO 이용-> DAO 객체 받기위한 service 객체 
		memberService.joinMember(vo);
		
		return "redirect:loginForm"; //리다이렉트 방식
	}
	
	@RequestMapping("/loginAction")
	public String loginAction(MemberVO vo, HttpSession session){
		
		SessionDataVO sessionData = memberService.loginProcess(vo);
		
		if(sessionData != null) {
			session.setAttribute("sessionData", sessionData);
			return "redirect:boardPage";
		
		}else {
			
		}
		
		return "loginFail";
	}
	
	@RequestMapping("/deleteMemberAction")
	public String deleteAction(MemberVO vo) {
		memberService.deleteMember(vo);
		
		return "deleteCompleteForm";
	}
	
	@RequestMapping("/deleteMemberForm")
	public String deleteMemberForm() {
	
		return "deleteMemberForm";
	}
	
	@RequestMapping("/logoutAction")
	public String logoutAction(HttpSession session) {
		
		session.invalidate();
		
		return "redirect:boardPage";
	}
}
