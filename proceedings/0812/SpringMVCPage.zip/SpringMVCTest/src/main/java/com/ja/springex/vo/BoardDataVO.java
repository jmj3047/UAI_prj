package com.ja.springex.vo;

import java.util.ArrayList;

public class BoardDataVO {

	private MemberVO memberVO;
	private ContentVO contentVO;
	private ArrayList<UploadFileVO> fileList;

	public BoardDataVO() {
		
	} // 우리가 직접 만든 VO니까(db에서 뽑아온 그 자체라고 말하기 어려움) 기본 생성자는 굳이 필요하지 않을 수 있음

	public BoardDataVO(MemberVO memberVO, ContentVO contentVO, ArrayList<UploadFileVO> fileList) {
		super();
		this.memberVO = memberVO;
		this.contentVO = contentVO;
		this.fileList = fileList;
	}

	public MemberVO getMemberVO() {
		return memberVO;
	}

	public void setMemberVO(MemberVO memberVO) {
		this.memberVO = memberVO;
	}

	public ContentVO getContentVO() {
		return contentVO;
	}

	public void setContentVO(ContentVO contentVO) {
		this.contentVO = contentVO;
	}

	public ArrayList<UploadFileVO> getFileList() {
		return fileList;
	}

	public void setFileList(ArrayList<UploadFileVO> fileList) {
		this.fileList = fileList;
	}

}
