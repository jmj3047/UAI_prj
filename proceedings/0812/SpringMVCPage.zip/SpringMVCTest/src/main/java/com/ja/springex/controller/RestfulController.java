package com.ja.springex.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.ja.springex.service.memberService;
import com.ja.springex.vo.MemberVO;
import com.ja.springex.vo.RestResponseDataVO;

@Controller
@ResponseBody
public class RestfulController {

	@Autowired
	private memberService memberService;
	
	@RequestMapping("/testRest")
	public String test() {
		
		return "qwerty"; // 여기로 포워딩되는 것이 아니라 문자열이 그대로 날아감(순수 데이터 그대로....!)
	}
	
	//Restful API 잘 활용하는 법!!
	//1. 서버 컨트롤러 구현(ResponseBody 붙여주기) - JSON 타입(키와 값을 가진 클래스)으로 DATA전달
	//2. AjAX(javascript)로 호출
	//3. 받은 데이터를 기반으로 UI 만들어내기(javascript 사용) *************얘가 핵심
	
	@RequestMapping("/isExistID")
	public RestResponseDataVO isExistID(MemberVO requestParam) {
		
		RestResponseDataVO result = new RestResponseDataVO();
		
		if(memberService.isExistID(requestParam)) { //true로 넘어오니까 연산자 필요 x
			result.setExist(true);
			result.setReason("중복된 아이디입니다");
		}
		
		return result;
	}
}
