package com.ja.springex.mapper;

import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;

import com.ja.springex.vo.MemberVO;

//인터페이스 선언 ---> DAO 선언, 이러이러한 쿼리가 있습니다.
public interface MembersSQLMapper {
	
	@Insert("INSERT INTO BOARD_MEMBERS VALUES(BOARD_MEMBERS_SEQ.NEXTVAL,#{m_id},#{m_pw},#{m_nick},#{m_phone},#{m_address},SYSDATE)")
	public void insert(MemberVO vo);
	
	@Select("SELECT * FROM BOARD_MEMBERS WHERE M_ID = #{id}")
	public MemberVO selectById(String id); //String 혹은 vo로 받아올 수 있음
	
	@Delete("DELETE FROM BOARD_MEMBERS WHERE M_IDX = #{m_idx}")
	public void deleteByIdx(MemberVO vo);
	
	@Select("SELECT * FROM BOARD_MEMBERS WHERE M_IDX = #{m_idx}")
	public MemberVO selectByIdx(
			@Param("m_idx") String idx // 변수에 annotation을 붙여서 전달 이름을 바꾸기
			);

	@Update("UPDATE BOARD_MEMBERS SET M_NICK = #{m_nick} WHERE M_IDX = #{m_idx}")
	public void update(MemberVO vo);
	
}
