package com.ja.springex.vo;

import java.util.ArrayList;

public class BoardDataPageVO {

	private PageVO pagevo;
	private ArrayList<BoardDataVO> dataList;
	
	public BoardDataPageVO() {}
	
	public BoardDataPageVO(PageVO pagevo, ArrayList<BoardDataVO> boardDataList) {
		super();
		this.pagevo = pagevo;
		this.dataList = dataList;
	}

	public PageVO getPagevo() {
		return pagevo;
	}

	public void setPagevo(PageVO pagevo) {
		this.pagevo = pagevo;
	}

	public ArrayList<BoardDataVO> getBoardDataList() {
		return dataList;
	}

	public void setBoardDataList(ArrayList<BoardDataVO> boardDataList) {
		this.dataList = boardDataList;
	}

}
