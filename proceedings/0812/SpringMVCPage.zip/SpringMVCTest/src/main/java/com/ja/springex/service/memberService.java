package com.ja.springex.service;

import com.ja.springex.vo.MemberVO;
import com.ja.springex.vo.SessionDataVO;

public interface memberService {

	public void joinMember(MemberVO vo);
	
	public SessionDataVO loginProcess(MemberVO vo);
	
	public void deleteMember(MemberVO vo);
	
	public boolean isExistID(MemberVO vo); // 참거짓으로 받기

	
}

