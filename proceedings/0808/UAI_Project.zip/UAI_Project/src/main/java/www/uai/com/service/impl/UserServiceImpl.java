package www.uai.com.service.impl;

import www.uai.com.service.UserService;

public class UserServiceImpl implements UserService{

}
