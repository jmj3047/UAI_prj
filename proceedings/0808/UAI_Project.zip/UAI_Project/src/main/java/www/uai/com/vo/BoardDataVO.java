package www.uai.com.vo;

public class BoardDataVO {

}
