package www.uai.com.mapper;

public interface ContentSQLMapper {

}
