package www.uai.com.service.impl;

import www.uai.com.service.ContentService;

public class ContentServiceImpl implements ContentService {

}
