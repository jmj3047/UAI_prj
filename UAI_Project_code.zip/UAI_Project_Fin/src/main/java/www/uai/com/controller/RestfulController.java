package www.uai.com.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import www.uai.com.service.*;
import www.uai.com.vo.*;

@Controller
@ResponseBody
public class RestfulController {
	
	@Autowired //(주입. UserController에서 userrService사용할수 있게됨)
	private UserService userService;

	@RequestMapping("/testRest")
	public String test() {
		
		return "AAAA";
	}
	
	
	//***Restful API 잘 활용하는 법***
	//1. 서버 컨트롤러 구현(ResponseBody) - JSON 타입으로 data 전달
	//2. AJAX(javascript)로 호출
	//3. 의미있는 데이터를 받고, 의도에 맞게 UI를 javascript로 만들어냄
	
	
	
	@RequestMapping("/isExistMID")
	public RestResponseDataVO isExistMID(MemberDataVO requestParam) {
		
		RestResponseDataVO result = new RestResponseDataVO();
		
		
		if(userService. isExistMID(requestParam) == true) {
			result.setExist(true);
		}
		
		
		return result;
	}
	
	@RequestMapping("/isExistMNick")
	public RestResponseDataVO isExistMNick(MemberDataVO requestParam) {
		
		RestResponseDataVO result = new RestResponseDataVO();
		
		
		if(userService. isExistMNick(requestParam) == true) {
			result.setExist(true);
		}
		
		
		return result;
	}
}