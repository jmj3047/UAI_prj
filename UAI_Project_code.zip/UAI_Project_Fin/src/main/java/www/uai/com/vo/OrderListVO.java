package www.uai.com.vo;

public class OrderListVO {

	public OrderDataVO orderDataVO;
	public ProductVO productVO;
	public PurchaseDataVO purchaseDataVO;
	
	public OrderListVO(OrderDataVO orderDataVO, ProductVO productVO, PurchaseDataVO purchaseDataVO) {
		super();
		this.orderDataVO = orderDataVO;
		this.productVO = productVO;
		this.purchaseDataVO = purchaseDataVO;
	}

	public OrderListVO() {}

	public OrderDataVO getOrderDataVO() {
		return orderDataVO;
	}

	public void setOrderDataVO(OrderDataVO orderDataVO) {
		this.orderDataVO = orderDataVO;
	}

	public ProductVO getProductVO() {
		return productVO;
	}

	public void setProductVO(ProductVO productVO) {
		this.productVO = productVO;
	}

	public PurchaseDataVO getPurchaseDataVO() {
		return purchaseDataVO;
	}

	public void setPurchaseDataVO(PurchaseDataVO purchaseDataVO) {
		this.purchaseDataVO = purchaseDataVO;
	}

}
