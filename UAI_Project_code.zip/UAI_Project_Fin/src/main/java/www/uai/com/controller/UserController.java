﻿package www.uai.com.controller;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import www.uai.com.service.UserService;
import www.uai.com.vo.AdminDataVO;
import www.uai.com.vo.MemberDataVO;
import www.uai.com.vo.SessionDataVO;

@Controller
public class UserController {
   
   @Autowired
   UserService userService;
   
   @RequestMapping("/loginForm")
   public String loginForm() {
      return "loginForm";
   }
   
   @RequestMapping("/memberLoginAction")
   public String memberLoginAction(MemberDataVO vo, HttpSession session) {
      SessionDataVO sessionData = userService.memberLoginProcess(vo);
      
      if(sessionData != null) {
         //로그인 성공
         session.setAttribute("sessionData", sessionData);
      
         return "redirect:mainPage";
      }else {
         
      }
      return "loginFail";
      }
   
   @RequestMapping("/adminLoginAction")
   public String adminLoginAction(AdminDataVO vo, HttpSession session) {
      SessionDataVO sessionData = userService.adminLoginProcess(vo);
      
      if(sessionData != null) {
         //로그인 성공
         session.setAttribute("sessionData", sessionData);
      
         return "redirect:sellerIndex.do";
      }else {
         
      }
      return "loginFail";
      }
   
   
   @RequestMapping("/joinMemberForm")
   public String joinMemberForm() {
      return "joinMemberForm";
   }
   
   
   @RequestMapping("/joinMemberAction")
   public String joinMemberAction(MemberDataVO vo, HttpSession session, String m_address1, String m_address2) {
      
	  String m_address = m_address1 + " " + m_address2;
	  vo.setM_address(m_address); 
	   
      userService.joinMember(vo);
      
      return "joinMemberComplete";
   }
   
   
   
   @RequestMapping("/logoutAction")
   public String logoutAction(HttpSession session) {
      
      session.invalidate();
      
      return "redirect:mainPage";
   }
   
 //jmj
   @RequestMapping("/updateMemberPage")
   public String updateMemberPage(MemberDataVO vo,org.springframework.ui.Model model, String m_idx) {
	   MemberDataVO memberdata =userService.selectByMIdx(m_idx);
	   model.addAttribute("memberdata", memberdata);
	   
	   return "updateMemberPage";
	   
   }
   
   @RequestMapping("/updateMemberAction")
   public String updateMemberAction(MemberDataVO vo, String m_address1, String m_address2) {
	   
	   String m_address = m_address1 + " " + m_address2;
	   vo.setM_address(m_address);
	  
	   userService.update(vo);
	   
	   
	   return "updateMemberComplete";
   }
   
   @RequestMapping("/updateMemberForm")
   public String updateMemberForm(org.springframework.ui.Model model, String m_idx) {
	   MemberDataVO memberdata =userService.selectByMIdx(m_idx);
	   model.addAttribute("memberdata", memberdata);
	   return "updateMemberForm";
	   
   }
   
   @RequestMapping("/deleteMemberAction")
   public String deleteMemberAction(MemberDataVO vo, HttpSession session) {
	   
	   session.invalidate();
	   vo.getM_idx();
	   userService.deleteMember(vo);
	   
	   return "deleteMemberSuccess";
   }
}