package www.uai.com.service.impl;

import www.uai.com.service.AdminService;
import www.uai.com.vo.AdminDataVO;
import www.uai.com.vo.SessionDataVO;

public class AdminServiceImpl implements AdminService {

   @Override
   public void joinAdmin(AdminDataVO adminDataVO) {
      // TODO Auto-generated method stub

   }

   @Override
   public SessionDataVO loginProcess(AdminDataVO AdminDataVO) {
      // TODO Auto-generated method stub
      return null;
   }

   @Override
   public boolean isExistID(AdminDataVO adminDataVO) {
      // TODO Auto-generated method stub
      return false;
   }

}