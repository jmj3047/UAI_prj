package www.uai.com.vo;

public class IdxVO {
	private String idx;
	
	

	public IdxVO() {
		
	}

	
	
	public IdxVO(String idx) {
		
		this.idx = idx;
	}



	public String getIdx() {
		return idx;
	}

	public void setIdx(String idx) {
		this.idx = idx;
	}
	
	
}
