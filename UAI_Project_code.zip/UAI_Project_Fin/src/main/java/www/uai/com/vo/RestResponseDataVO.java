package www.uai.com.vo;

public class RestResponseDataVO {
	private boolean isExist;
	
	public RestResponseDataVO() {
		
	}

	public RestResponseDataVO(boolean isExist) {
		super();
		this.isExist = isExist;
	}

	public boolean isExist() {
		return isExist;
	}

	public void setExist(boolean isExist) {
		this.isExist = isExist;
	}
	
	

}